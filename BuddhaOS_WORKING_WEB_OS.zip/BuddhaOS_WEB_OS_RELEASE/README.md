# BuddhaOS Web Operating System Simulation

This package contains BuddhaOS as a browser-based operating-system simulation.

It is not a native bootable OS. It is a fictional BIOS-era OS interface built entirely with:

- HTML
- CSS
- JavaScript

## How to run locally

Open:

```txt
index.html
```

in any modern browser.

## How to publish on GitHub Pages

1. Upload `index.html` to the root of your GitHub Pages repository.
2. Go to repository Settings.
3. Open Pages.
4. Set source to the main branch/root folder.
5. Visit your GitHub Pages URL.

## Features

- BIOS-style boot sequence
- CRT flicker and scanlines
- Matrix rain
- System log
- Fake filesystem
- Fake process table
- Command line interpreter
- Interactive modules
- Hidden commands
- Password unlock with `manhattan`

## Commands

```txt
help
ls
ls /core
open worlds
open music
open market
open fashion
open buddha
open archive
open shop
open arcade
open lore
run mantra
matrix
recurse
clear
manhattan
core
void
awaken
```

## Important

This is the working OS-style version for the web.

If you want a real bootable BIOS image, use the assembly-based BuddhaOS package instead and run it in QEMU.

# Merged PROJECTMANHATTAN BuddhaOS

This package merges the finished PROJECTMANHATTAN BuddhaOS with the uploaded website source.

Uploaded site title:

```txt
A BIT BIZAARE — fenix_the_producer × Q@W@RD
```

## Included files

- `boot.asm` — BIOS boot sector
- `kernel.asm` — real-mode BuddhaOS shell
- `Makefile` — NASM/QEMU build commands
- `README.md` — this file
- `web/index.html` — the uploaded A BIT BIZAARE website source

## Build

```bash
make
make run
```

Manual:

```bash
nasm -f bin boot.asm -o boot.bin
nasm -f bin kernel.asm -o kernel.bin
cat boot.bin kernel.bin > merged_projectmanhattan_buddhaos.img
qemu-system-i386 -drive format=raw,file=merged_projectmanhattan_buddhaos.img
```

## Website-to-OS mapping

The uploaded HTML includes the full A BIT BIZAARE universe: music, marketplace, fashion, `.buddha`, archive, shop, arcade, lore, passcode/failsafe, matrix rain, field readout, footer/social links, 432 Hz, seven worlds, and infinity archive.

Those website features become shell commands:

- `SITE`
- `NAV`
- `WORLDS`
- `MUSIC`
- `MARKET`
- `FASHION`
- `BUDDHA`
- `ARCHIVE`
- `SHOP`
- `ARCADE`
- `LORE`
- `GATE`
- `SOCIAL`
- `MATRIX`
- `READOUT`
- `FREQ`
- `BEER`
- `MONEY`
- `MANTRA`
- `CLS`
- `REBOOT`

## Purpose

The web page remains the visual reference.
The OS shell is the BIOS-era translation of that same universe.


## Optimization Pass

See `OPTIMIZATION_REPORT.md` for the full debugging, redundancy, performance, and crash-prevention report.

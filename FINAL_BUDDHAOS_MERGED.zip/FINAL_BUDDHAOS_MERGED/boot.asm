[org 0x7C00]
bits 16

; ============================================================
; A BIT BIZAARE / PROJECTMANHATTAN / BuddhaOS
; Optimized boot sector
; ============================================================

KERNEL_SEG     equ 0x1000
KERNEL_OFF     equ 0x0000
KERNEL_SECTORS equ 52

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    sti

    mov [boot_drive], dl

    ; Standard 80x25 text mode.
    mov ax, 0x0003
    int 0x10

    mov si, boot_msg
    call puts

    ; Reset disk before read for more predictable BIOS behavior.
    xor ah, ah
    mov dl, [boot_drive]
    int 0x13
    jc disk_error

    ; Load stage-2 kernel immediately after boot sector.
    mov ax, KERNEL_SEG
    mov es, ax
    xor bx, bx

    mov ah, 0x02
    mov al, KERNEL_SECTORS
    xor ch, ch
    mov cl, 0x02
    xor dh, dh
    mov dl, [boot_drive]
    int 0x13
    jc disk_error

    jmp KERNEL_SEG:KERNEL_OFF

disk_error:
    mov si, disk_msg
    call puts

halt:
    cli
.hang:
    hlt
    jmp .hang

puts:
    mov ah, 0x0E
.next:
    lodsb
    test al, al
    jz .done
    int 0x10
    jmp .next
.done:
    ret

boot_msg db "A BIT BIZAARE // PROJECTMANHATTAN BuddhaOS",13,10
         db "$ design = identity",13,10
         db "$ archive = waking",13,10,0

disk_msg db "ERROR: kernel unavailable. archive remains asleep.",13,10,0
boot_drive db 0

times 510-($-$$) db 0
dw 0xAA55

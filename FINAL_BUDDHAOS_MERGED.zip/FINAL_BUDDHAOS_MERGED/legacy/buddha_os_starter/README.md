# .buddha OS

A tiny 1990s-style BIOS operating system expanded from the original boot-sector mantra.

## Features

- BIOS boot sector at `0x7C00`
- Stage-2 real-mode kernel
- Text-mode shell
- Commands: `HELP`, `CLS`, `MANTRA`, `ABOUT`, `TIME`, `REBOOT`

## Build and run

```bash
make
make run
```

Manual:

```bash
nasm -f bin boot.asm -o boot.bin
nasm -f bin kernel.asm -o kernel.bin
cat boot.bin kernel.bin > buddha.img
qemu-system-i386 -drive format=raw,file=buddha.img
```

This is the realistic next step from a 15-line boot sector: the boot sector loads a larger kernel, and the kernel becomes the operating system.

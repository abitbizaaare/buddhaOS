[org 0x0000]
bits 16

start:
    mov ax, cs
    mov ds, ax
    mov es, ax
    mov ax, 0x0003
    int 0x10
    mov si, banner
    call print_string

shell:
    mov si, prompt
    call print_string
    mov di, input_buffer
    call read_line

    mov si, input_buffer
    mov di, cmd_help
    call strcmp
    je do_help

    mov si, input_buffer
    mov di, cmd_cls
    call strcmp
    je do_cls

    mov si, input_buffer
    mov di, cmd_mantra
    call strcmp
    je do_mantra

    mov si, input_buffer
    mov di, cmd_about
    call strcmp
    je do_about

    mov si, input_buffer
    mov di, cmd_time
    call strcmp
    je do_time

    mov si, input_buffer
    mov di, cmd_reboot
    call strcmp
    je do_reboot

    cmp byte [input_buffer], 0
    je shell

    mov si, unknown
    call print_string
    jmp shell

do_help:
    mov si, help_text
    call print_string
    jmp shell

do_cls:
    mov ax, 0x0003
    int 0x10
    jmp shell

do_mantra:
    mov si, mantra
    call print_string
    jmp shell

do_about:
    mov si, about
    call print_string
    jmp shell

do_time:
    call print_time
    jmp shell

do_reboot:
    int 0x19
    jmp $

print_char:
    mov ah, 0x0E
    int 0x10
    ret

print_string:
.next:
    lodsb
    cmp al, 0
    je .done
    call print_char
    jmp .next
.done:
    ret

newline:
    mov al, 13
    call print_char
    mov al, 10
    call print_char
    ret

read_line:
    xor cx, cx
.read:
    mov ah, 0x00
    int 0x16
    cmp al, 13
    je .enter
    cmp al, 8
    je .backspace
    cmp cx, 63
    jae .read
    stosb
    inc cx
    call print_char
    jmp .read
.backspace:
    cmp cx, 0
    je .read
    dec di
    dec cx
    mov al, 8
    call print_char
    mov al, ' '
    call print_char
    mov al, 8
    call print_char
    jmp .read
.enter:
    mov al, 0
    stosb
    call newline
    ret

strcmp:
.loop:
    mov al, [si]
    mov bl, [di]
    cmp al, bl
    jne .noteq
    cmp al, 0
    je .eq
    inc si
    inc di
    jmp .loop
.eq:
    xor ax, ax
    ret
.noteq:
    mov ax, 1
    ret

print_hex_digit:
    and al, 0x0F
    cmp al, 9
    jbe .num
    add al, 'A' - 10
    jmp print_char
.num:
    add al, '0'
    jmp print_char

print_bcd:
    push ax
    mov ah, al
    shr al, 4
    call print_hex_digit
    mov al, ah
    call print_hex_digit
    pop ax
    ret

print_time:
    mov ah, 0x02
    int 0x1A
    jc .fail
    mov si, time_prefix
    call print_string
    mov al, ch
    call print_bcd
    mov al, ':'
    call print_char
    mov al, cl
    call print_bcd
    mov al, ':'
    call print_char
    mov al, dh
    call print_bcd
    call newline
    ret
.fail:
    mov si, time_fail
    call print_string
    ret

banner db 13,10
       db "========================================",13,10
       db " .buddha OS 0.1 // real-mode shell",13,10
       db " 1990s-style BIOS operating system",13,10
       db "========================================",13,10
       db "type HELP",13,10,13,10,0

prompt db "buddha> ",0
cmd_help db "HELP",0
cmd_cls db "CLS",0
cmd_mantra db "MANTRA",0
cmd_about db "ABOUT",0
cmd_time db "TIME",0
cmd_reboot db "REBOOT",0

help_text db "commands:",13,10
          db "  HELP    - show this screen",13,10
          db "  CLS     - clear screen",13,10
          db "  MANTRA  - print the first word",13,10
          db "  ABOUT   - system identity",13,10
          db "  TIME    - show BIOS clock",13,10
          db "  REBOOT  - reboot through BIOS",13,10,0

mantra db "suchness...",13,10,0
about db ".buddha OS is a tiny BIOS-era operating system shell.",13,10
      db "It lives in real mode and speaks through interrupts.",13,10,0
unknown db "unknown command. type HELP.",13,10,0
time_prefix db "bios time: ",0
time_fail db "time unavailable",13,10,0
input_buffer times 64 db 0

times (24*512)-($-$$) db 0

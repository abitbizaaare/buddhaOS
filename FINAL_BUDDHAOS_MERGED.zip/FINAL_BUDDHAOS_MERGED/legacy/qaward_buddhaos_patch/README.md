# Q@W@RD BuddhaOS Patch

This applies the design language of the Q@W@RD / JERE.COM website to the BuddhaOS boot-sector project.

## What changed

The original BuddhaOS features are replaced with Q@W@RD-style shell commands:

- `QAWARD` — black/green project identity
- `JERE` — JERE.COM BMX video-feed identity
- `FEED` — video feed subsystem concept
- `ARCHIVE` — clip/archive subsystem concept
- `BMX` — field directive for BMX curation
- `SCAN` — matrix rain terminal burst
- `BEER` — white ASCII beer-can display
- `MONEY` — `$` + `ERROR` terminal burst
- `MANTRA` — original `suchness...`
- `CLS`
- `REBOOT`

## Build

```bash
make
make run
```

Manual:

```bash
nasm -f bin boot.asm -o boot.bin
nasm -f bin kernel.asm -o kernel.bin
cat boot.bin kernel.bin > qaward_buddhaos.img
qemu-system-i386 -drive format=raw,file=qaward_buddhaos.img
```

## Concept

The website became:

```txt
JERE.COM
BMX clips
green matrix background
white ASCII mobile beer-can display
money / ERROR visual layer
```

This OS patch turns those ideas into a BIOS-era command shell.

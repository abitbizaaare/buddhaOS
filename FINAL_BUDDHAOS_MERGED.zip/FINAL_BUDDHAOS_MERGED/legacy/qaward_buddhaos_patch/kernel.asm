[org 0x0000]
bits 16

; ============================================================
; BuddhaOS x Q@W@RD kernel
; Real-mode shell styled after the Q@W@RD/Jere Matrix website.
; ============================================================

start:
    mov ax, cs
    mov ds, ax
    mov es, ax

    mov ax, 0x0003
    int 0x10

    call set_green
    mov si, banner
    call print_string

shell:
    call set_green
    mov si, prompt
    call print_string

    mov di, input_buffer
    call read_line

    mov si, input_buffer
    mov di, cmd_help
    call strcmp
    je do_help

    mov si, input_buffer
    mov di, cmd_qaward
    call strcmp
    je do_qaward

    mov si, input_buffer
    mov di, cmd_jere
    call strcmp
    je do_jere

    mov si, input_buffer
    mov di, cmd_feed
    call strcmp
    je do_feed

    mov si, input_buffer
    mov di, cmd_archive
    call strcmp
    je do_archive

    mov si, input_buffer
    mov di, cmd_bmx
    call strcmp
    je do_bmx

    mov si, input_buffer
    mov di, cmd_scan
    call strcmp
    je do_scan

    mov si, input_buffer
    mov di, cmd_beer
    call strcmp
    je do_beer

    mov si, input_buffer
    mov di, cmd_money
    call strcmp
    je do_money

    mov si, input_buffer
    mov di, cmd_mantra
    call strcmp
    je do_mantra

    mov si, input_buffer
    mov di, cmd_cls
    call strcmp
    je do_cls

    mov si, input_buffer
    mov di, cmd_reboot
    call strcmp
    je do_reboot

    cmp byte [input_buffer], 0
    je shell

    call set_red
    mov si, unknown
    call print_string
    jmp shell

do_help:
    call set_white
    mov si, help_text
    call print_string
    jmp shell

do_qaward:
    call set_green
    mov si, qaward_text
    call print_string
    jmp shell

do_jere:
    call set_green
    mov si, jere_text
    call print_string
    jmp shell

do_feed:
    call set_white
    mov si, feed_text
    call print_string
    jmp shell

do_archive:
    call set_green
    mov si, archive_text
    call print_string
    jmp shell

do_bmx:
    call set_gold
    mov si, bmx_text
    call print_string
    jmp shell

do_scan:
    call set_green
    mov si, scan_start
    call print_string
    call matrix_rain
    mov si, scan_end
    call print_string
    jmp shell

do_beer:
    call set_white
    mov si, beer_can
    call print_string
    jmp shell

do_money:
    call set_green
    call money_error
    jmp shell

do_mantra:
    call set_green
    mov si, mantra
    call print_string
    jmp shell

do_cls:
    mov ax, 0x0003
    int 0x10
    jmp shell

do_reboot:
    int 0x19
    jmp $

; ----------------------------
; Color helpers
; ----------------------------

set_green:
    mov byte [text_attr], 0x0A
    ret

set_white:
    mov byte [text_attr], 0x0F
    ret

set_gold:
    mov byte [text_attr], 0x0E
    ret

set_red:
    mov byte [text_attr], 0x0C
    ret

; BIOS teletype uses BL color in graphics modes only, but this keeps
; the shell ready for VGA evolution. In text mode the BIOS default is used.
print_char:
    mov ah, 0x0E
    mov bh, 0x00
    mov bl, [text_attr]
    int 0x10
    ret

print_string:
.next:
    lodsb
    cmp al, 0
    je .done
    call print_char
    jmp .next
.done:
    ret

newline:
    mov al, 13
    call print_char
    mov al, 10
    call print_char
    ret

read_line:
    xor cx, cx
.read:
    mov ah, 0x00
    int 0x16

    cmp al, 13
    je .enter

    cmp al, 8
    je .backspace

    cmp cx, 63
    jae .read

    cmp al, 'a'
    jb .store
    cmp al, 'z'
    ja .store
    sub al, 32

.store:
    stosb
    inc cx
    call print_char
    jmp .read

.backspace:
    cmp cx, 0
    je .read
    dec di
    dec cx
    mov al, 8
    call print_char
    mov al, ' '
    call print_char
    mov al, 8
    call print_char
    jmp .read

.enter:
    mov al, 0
    stosb
    call newline
    ret

strcmp:
.loop:
    mov al, [si]
    mov bl, [di]
    cmp al, bl
    jne .noteq
    cmp al, 0
    je .eq
    inc si
    inc di
    jmp .loop
.eq:
    xor ax, ax
    ret
.noteq:
    mov ax, 1
    ret

matrix_rain:
    mov cx, 12
.row:
    push cx
    mov si, matrix_line
    call print_string
    pop cx
    loop .row
    ret

money_error:
    mov cx, 10
.row:
    push cx
    mov si, money_line
    call print_string
    pop cx
    loop .row
    ret

; ----------------------------
; Data
; ----------------------------

text_attr db 0x0A

banner db 13,10
       db "====================================================",13,10
       db " Q@W@RD BuddhaOS // blackwater terminal build",13,10
       db " JERE.COM / BMX archive / Matrix shell",13,10
       db "====================================================",13,10
       db "type HELP",13,10,13,10,0

prompt db "qaward> ",0

cmd_help db "HELP",0
cmd_qaward db "QAWARD",0
cmd_jere db "JERE",0
cmd_feed db "FEED",0
cmd_archive db "ARCHIVE",0
cmd_bmx db "BMX",0
cmd_scan db "SCAN",0
cmd_beer db "BEER",0
cmd_money db "MONEY",0
cmd_mantra db "MANTRA",0
cmd_cls db "CLS",0
cmd_reboot db "REBOOT",0

help_text db "commands:",13,10
          db "  QAWARD   - project identity",13,10
          db "  JERE     - jere.com system identity",13,10
          db "  FEED     - video feed concept",13,10
          db "  ARCHIVE  - local archive concept",13,10
          db "  BMX      - field directive",13,10
          db "  SCAN     - matrix rain diagnostic",13,10
          db "  BEER     - white ASCII can display",13,10
          db "  MONEY    - $$$ + ERROR background burst",13,10
          db "  MANTRA   - original boot word",13,10
          db "  CLS      - clear screen",13,10
          db "  REBOOT   - reboot through BIOS",13,10,0

qaward_text db "Q@W@RD: signal-first archive system.",13,10
            db "$ style = black/green terminal",13,10
            db "$ rule  = document what others overlook",13,10,0

jere_text db "JERE.COM: pro BMX clip feed.",13,10
          db "$ mode = rider-owned footage",13,10
          db "$ goal = gather, curate, publish, repeat",13,10,0

feed_text db "FEED subsystem:",13,10
          db "  vertical clips, raw uploads, captions, tags.",13,10
          db "  future: disk-backed sectors instead of localStorage.",13,10,0

archive_text db "ARCHIVE subsystem:",13,10
             db "  clips + notes + riders + spots + field reports.",13,10
             db "  future: flat file table and searchable index.",13,10,0

bmx_text db "PROJECT BMX:",13,10
         db "  gather content. find clips. curate strange scenes.",13,10
         db "  if it has a story, preserve it.",13,10,0

scan_start db "SCAN: matrix rain initializing...",13,10,0
scan_end db "SCAN COMPLETE: signal continues.",13,10,0
matrix_line db "0101 $$$ Q@W@RD @ JERE.COM # BMX % ARCHIVE $$$ 1010",13,10,0
money_line db "$$$$$$$$ ERROR $$$$$$$$ $$$ JERE.COM $$$ ERROR $$$$$$$$",13,10,0
mantra db "suchness...",13,10,0

beer_can db 13,10
         db "        .--------.",13,10
         db "       /  ______  \",13,10
         db "      /  /      \  \",13,10
         db "     |  | JERE.  |  |",13,10
         db "     |  |  COM   |  |",13,10
         db "     |  |        |  |",13,10
         db "     |  |  $$$$  |  |",13,10
         db "     |  | ERROR  |  |",13,10
         db "     |  |  BMX   |  |",13,10
         db "      \  \______/  /",13,10
         db "       \          /",13,10
         db "        '--------'",13,10
         db "          ||  ||",13,10
         db "          ||  ||",13,10
         db "        .--------.",13,10,13,10,0

unknown db "ERROR: unknown command. type HELP.",13,10,0
input_buffer times 64 db 0

times (32*512)-($-$$) db 0

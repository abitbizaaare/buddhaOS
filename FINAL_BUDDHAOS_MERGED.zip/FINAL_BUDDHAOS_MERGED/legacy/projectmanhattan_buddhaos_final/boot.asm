[org 0x7C00]
bits 16

; ============================================================
; PROJECTMANHATTAN BuddhaOS boot sector
; A BIT BIZAARE / Q@W@RD BIOS loader
; ============================================================

KERNEL_SEG equ 0x1000
KERNEL_OFF equ 0x0000
KERNEL_SECTORS equ 48

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    sti

    mov [boot_drive], dl

    mov ax, 0x0003
    int 0x10

    mov si, boot_msg
    call print_string

    mov ax, KERNEL_SEG
    mov es, ax
    mov bx, KERNEL_OFF

    mov ah, 0x02
    mov al, KERNEL_SECTORS
    mov ch, 0x00
    mov cl, 0x02
    mov dh, 0x00
    mov dl, [boot_drive]
    int 0x13
    jc disk_error

    jmp KERNEL_SEG:KERNEL_OFF

disk_error:
    mov si, disk_msg
    call print_string

hang:
    cli
    hlt
    jmp hang

print_string:
    mov ah, 0x0E
.next:
    lodsb
    cmp al, 0
    je .done
    int 0x10
    jmp .next
.done:
    ret

boot_msg db "A BIT BIZAARE // PROJECTMANHATTAN loader",13,10
         db "$ frequency = 432hz",13,10
         db "$ archive = infinity",13,10
         db "$ buddha = waking at 0x7C00",13,10,0

disk_msg db "ERROR: PROJECTMANHATTAN kernel unavailable",13,10,0
boot_drive db 0

times 510-($-$$) db 0
dw 0xAA55

# PROJECTMANHATTAN BuddhaOS

A finished BuddhaOS build using the design language of the A BIT BIZAARE / PROJECTMANHATTAN site.

## Design translated into BIOS shell

The public site presents:

- **A BIT BIZAARE** as the central identity
- “where design becomes identity”
- 7 worlds / 432 Hz / ∞ archive
- music, marketplace, fashion engine, .buddha archive, lookbook, shop, arcade
- whale signal / frequency / safe infinity
- passcode + Oppenheimer failsafe
- “everything is vibration, everything is drift”

This shell maps those ideas into real-mode commands.

## Commands

- `HELP`
- `WORLDS`
- `MUSIC`
- `MARKET`
- `FASHION`
- `BUDDHA`
- `ARCHIVE`
- `SHOP`
- `ARCADE`
- `LORE`
- `WHALE`
- `FREQ`
- `PASSCODE`
- `FAILSAFE`
- `TEACHER`
- `DRIFT`
- `MATRIX`
- `BEER`
- `MONEY`
- `MANTRA`
- `CLS`
- `REBOOT`

## Build

```bash
make
make run
```

Manual:

```bash
nasm -f bin boot.asm -o boot.bin
nasm -f bin kernel.asm -o kernel.bin
cat boot.bin kernel.bin > projectmanhattan_buddhaos.img
qemu-system-i386 -drive format=raw,file=projectmanhattan_buddhaos.img
```

## What “finished” means here

This is a complete bootable toy OS shell:

1. BIOS loads boot sector at `0x7C00`.
2. Boot sector loads the kernel sectors.
3. Kernel opens the PROJECTMANHATTAN shell.
4. Commands expose the site’s worlds as operating-system modules.

It remains real-mode and BIOS-backed, matching the 1990s-style OS direction.

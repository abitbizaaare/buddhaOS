[org 0x0000]
bits 16

; ============================================================
; Merged PROJECTMANHATTAN BuddhaOS kernel
; Shell modules mirror the uploaded A BIT BIZAARE website.
; ============================================================

start:
    mov ax, cs
    mov ds, ax
    mov es, ax

    mov ax, 0x0003
    int 0x10

    call set_green
    mov si, banner
    call print_string

main_loop:
    call set_green
    mov si, prompt
    call print_string

    mov di, input_buffer
    call read_line

    mov si, input_buffer
    mov di, cmd_help
    call strcmp
    je do_help

    mov si, input_buffer
    mov di, cmd_site
    call strcmp
    je do_site

    mov si, input_buffer
    mov di, cmd_nav
    call strcmp
    je do_nav

    mov si, input_buffer
    mov di, cmd_worlds
    call strcmp
    je do_worlds

    mov si, input_buffer
    mov di, cmd_music
    call strcmp
    je do_music

    mov si, input_buffer
    mov di, cmd_market
    call strcmp
    je do_market

    mov si, input_buffer
    mov di, cmd_fashion
    call strcmp
    je do_fashion

    mov si, input_buffer
    mov di, cmd_buddha
    call strcmp
    je do_buddha

    mov si, input_buffer
    mov di, cmd_archive
    call strcmp
    je do_archive

    mov si, input_buffer
    mov di, cmd_shop
    call strcmp
    je do_shop

    mov si, input_buffer
    mov di, cmd_arcade
    call strcmp
    je do_arcade

    mov si, input_buffer
    mov di, cmd_lore
    call strcmp
    je do_lore

    mov si, input_buffer
    mov di, cmd_gate
    call strcmp
    je do_gate

    mov si, input_buffer
    mov di, cmd_social
    call strcmp
    je do_social

    mov si, input_buffer
    mov di, cmd_matrix
    call strcmp
    je do_matrix

    mov si, input_buffer
    mov di, cmd_readout
    call strcmp
    je do_readout

    mov si, input_buffer
    mov di, cmd_freq
    call strcmp
    je do_freq

    mov si, input_buffer
    mov di, cmd_beer
    call strcmp
    je do_beer

    mov si, input_buffer
    mov di, cmd_money
    call strcmp
    je do_money

    mov si, input_buffer
    mov di, cmd_mantra
    call strcmp
    je do_mantra

    mov si, input_buffer
    mov di, cmd_cls
    call strcmp
    je do_cls

    mov si, input_buffer
    mov di, cmd_reboot
    call strcmp
    je do_reboot

    cmp byte [input_buffer], 0
    je main_loop

    call set_red
    mov si, unknown
    call print_string
    jmp main_loop

do_help:
    call set_white
    mov si, help_text
    call print_string
    jmp main_loop

do_site:
    call set_green
    mov si, site_text
    call print_string
    jmp main_loop

do_nav:
    call set_white
    mov si, nav_text
    call print_string
    jmp main_loop

do_worlds:
    call set_gold
    mov si, worlds_text
    call print_string
    jmp main_loop

do_music:
    call set_green
    mov si, music_text
    call print_string
    jmp main_loop

do_market:
    call set_green
    mov si, market_text
    call print_string
    jmp main_loop

do_fashion:
    call set_gold
    mov si, fashion_text
    call print_string
    jmp main_loop

do_buddha:
    call set_white
    mov si, buddha_art
    call print_string
    jmp main_loop

do_archive:
    call set_green
    mov si, archive_text
    call print_string
    jmp main_loop

do_shop:
    call set_gold
    mov si, shop_text
    call print_string
    jmp main_loop

do_arcade:
    call set_red
    mov si, arcade_text
    call print_string
    jmp main_loop

do_lore:
    call set_white
    mov si, lore_text
    call print_string
    jmp main_loop

do_gate:
    call set_red
    mov si, gate_text
    call print_string
    jmp main_loop

do_social:
    call set_green
    mov si, social_text
    call print_string
    jmp main_loop

do_matrix:
    call set_green
    mov si, matrix_start
    call print_string
    call matrix_rain
    mov si, matrix_end
    call print_string
    jmp main_loop

do_readout:
    call set_green
    mov si, readout_text
    call print_string
    call matrix_rain
    jmp main_loop

do_freq:
    call set_gold
    mov si, freq_text
    call print_string
    jmp main_loop

do_beer:
    call set_white
    mov si, beer_can
    call print_string
    jmp main_loop

do_money:
    call set_green
    call money_error
    jmp main_loop

do_mantra:
    call set_green
    mov si, mantra
    call print_string
    jmp main_loop

do_cls:
    mov ax, 0x0003
    int 0x10
    jmp main_loop

do_reboot:
    int 0x19
    jmp $

; ----------------------------
; Helpers
; ----------------------------

set_green:
    mov byte [text_attr], 0x0A
    ret

set_white:
    mov byte [text_attr], 0x0F
    ret

set_gold:
    mov byte [text_attr], 0x0E
    ret

set_red:
    mov byte [text_attr], 0x0C
    ret

print_char:
    mov ah, 0x0E
    mov bh, 0
    mov bl, [text_attr]
    int 0x10
    ret

print_string:
.next:
    lodsb
    cmp al, 0
    je .done
    call print_char
    jmp .next
.done:
    ret

read_line:
    xor cx, cx
.read:
    mov ah, 0
    int 0x16

    cmp al, 13
    je .enter
    cmp al, 8
    je .backspace
    cmp cx, 63
    jae .read

    cmp al, 'a'
    jb .store
    cmp al, 'z'
    ja .store
    sub al, 32

.store:
    stosb
    inc cx
    call print_char
    jmp .read

.backspace:
    cmp cx, 0
    je .read
    dec di
    dec cx
    mov al, 8
    call print_char
    mov al, ' '
    call print_char
    mov al, 8
    call print_char
    jmp .read

.enter:
    mov al, 0
    stosb
    mov al, 13
    call print_char
    mov al, 10
    call print_char
    ret

strcmp:
.loop:
    mov al, [si]
    mov bl, [di]
    cmp al, bl
    jne .noteq
    cmp al, 0
    je .eq
    inc si
    inc di
    jmp .loop
.eq:
    xor ax, ax
    ret
.noteq:
    mov ax, 1
    ret

matrix_rain:
    mov cx, 12
.row:
    push cx
    mov si, matrix_line
    call print_string
    pop cx
    loop .row
    ret

money_error:
    mov cx, 10
.row:
    push cx
    mov si, money_line
    call print_string
    pop cx
    loop .row
    ret

; ----------------------------
; Data
; ----------------------------

text_attr db 0x0A

banner db 13,10
       db "========================================================",13,10
       db " A BIT BIZAARE // PROJECTMANHATTAN BuddhaOS",13,10
       db " merged with uploaded website source",13,10
       db " where design becomes identity",13,10
       db "========================================================",13,10
       db "7 worlds | 432 hz | infinity archive | type HELP",13,10,13,10,0

prompt db "bizaare> ",0

cmd_help db "HELP",0
cmd_site db "SITE",0
cmd_nav db "NAV",0
cmd_worlds db "WORLDS",0
cmd_music db "MUSIC",0
cmd_market db "MARKET",0
cmd_fashion db "FASHION",0
cmd_buddha db "BUDDHA",0
cmd_archive db "ARCHIVE",0
cmd_shop db "SHOP",0
cmd_arcade db "ARCADE",0
cmd_lore db "LORE",0
cmd_gate db "GATE",0
cmd_social db "SOCIAL",0
cmd_matrix db "MATRIX",0
cmd_readout db "READOUT",0
cmd_freq db "FREQ",0
cmd_beer db "BEER",0
cmd_money db "MONEY",0
cmd_mantra db "MANTRA",0
cmd_cls db "CLS",0
cmd_reboot db "REBOOT",0

help_text db "commands:",13,10
          db "  SITE     - website identity",13,10
          db "  NAV      - web nav translated to shell",13,10
          db "  WORLDS   - seven doors, one archive",13,10
          db "  MUSIC    - fenix_the_producer",13,10
          db "  MARKET   - q@w@rd marketplace",13,10
          db "  FASHION  - q@w@rd x zengriffeyjr",13,10
          db "  BUDDHA   - meditating ASCII stage",13,10
          db "  ARCHIVE  - garment/lookbook archive",13,10
          db "  SHOP     - nick knacks",13,10
          db "  ARCADE   - matrix games",13,10
          db "  LORE     - sound/system/ritual",13,10
          db "  GATE     - oppenheimer failsafe",13,10
          db "  SOCIAL   - footer links as shell objects",13,10
          db "  MATRIX   - canvas rain translated to text",13,10
          db "  READOUT  - field readout burst",13,10
          db "  FREQ     - frequency/loop/archive stats",13,10
          db "  BEER     - ASCII can artifact",13,10
          db "  MONEY    - money/error field",13,10
          db "  MANTRA   - suchness",13,10
          db "  CLS      - clear screen",13,10
          db "  REBOOT   - reboot BIOS",13,10,0

site_text db "SITE: A BIT BIZAARE",13,10
          db "fenix_the_producer x Q@W@RD x ZenGriffeyJR",13,10
          db "meta: music, identity marketplace, fashion engine,",13,10
          db "archive, shop, arcade, all in one.",13,10,0

nav_text db "NAV:",13,10
         db "music/ marketplace/ fashion/ buddha/ archive/ shop/ arcade/",13,10
         db "In BuddhaOS these become shell modules.",13,10,0

worlds_text db "SEVEN DOORS, ONE ARCHIVE:",13,10
           db "1 MUSIC    2 MARKETPLACE 3 FASHION",13,10
           db "4 BUDDHA   5 ARCHIVE     6 SHOP",13,10
           db "7 ARCADE",13,10,0

music_text db "MUSIC: fenix_the_producer",13,10
          db "tracks, bio, playable archive, campus-scale soundtracks.",13,10,0

market_text db "MARKETPLACE: Q@W@RD",13,10
           db "Depop x SoundCloud identity market.",13,10
           db "Garments, tracks, fragments, frequency engine.",13,10,0

fashion_text db "FASHION:",13,10
            db "Q@W@RD x ZenGriffeyJR whale-AI fashion engine.",13,10
            db "silhouette, texture, rarity, fit building, drop calendar.",13,10,0

archive_text db "ARCHIVE:",13,10
             db "Samue jacket, streetwear, Dodgers fits,",13,10
             db "first garments in the Q@W@RD archive.",13,10,0

shop_text db "SHOP: Nick Knacks",13,10
         db "Flower Power, Become a Tree, Life is the Revolution.",13,10,0

arcade_text db "ARCADE:",13,10
           db "Code Storm and Matrix Sudoku Gate.",13,10
           db "Do not forget the magic word.",13,10,0

lore_text db "LORE:",13,10
          db "sound: campus-scale soundtrack",13,10
          db "system: Q@W@RD identity marketplace",13,10
          db "ritual: passcode, loop, whale, suchness",13,10,0

gate_text db "OPPENHEIMER FAILSAFE:",13,10
          db "who is the teacher without the hat?",13,10
          db "accepted codes: suchness, 42, teacher without hat.",13,10
          db "BIOS mode: consciousness remains safely reversible.",13,10,0

social_text db "SOCIAL:",13,10
           db "SoundCloud | BandLab | YouTube | TikTok | Instagram | GitHub",13,10,0

freq_text db "STATS:",13,10
          db "worlds = 7",13,10
          db "hz = 432",13,10
          db "loops = counting",13,10
          db "archive = infinity",13,10,0

readout_text db "FIELD READOUT:",13,10
             db "identity frequency closet sound design qaward resonance buddha whale",13,10,0

matrix_start db "MATRIX: translating canvas rain to BIOS text...",13,10,0
matrix_end db "MATRIX: signal stable.",13,10,0
matrix_line db "$$$ A BIT BIZAARE % Q@W@RD # WHALE @ ARCHIVE 0101 $$$",13,10,0
money_line db "$$$$$ ERROR $$$ A BIT BIZAARE $$$ ERROR $$$ Q@W@RD $$$$",13,10,0
mantra db "suchness...",13,10,0

buddha_art db 13,10
           db "           _ooooo_",13,10
           db "        .o888888888o.",13,10
           db "       8888  *  * 8888",13,10
           db "      88       _       88",13,10
           db "      88     \\___/     88",13,10
           db "       88.           .88",13,10
           db "        '88oo_____oo88'",13,10
           db "            /|   |\\",13,10
           db "           / |   | \\",13,10
           db "        __/  |___|  \\__",13,10
           db "      .'   _/     \\_   '.",13,10
           db "     /   .'  .---.  '.   \\",13,10
           db "    /___/   (     )   \\___\\",13,10
           db "       /__   \\___/   __\\",13,10
           db "      (___)   ___   (___)",13,10
           db "        \\____/   \\____/",13,10,13,10,0

beer_can db 13,10
         db "        .--------.",13,10
         db "       /  ______  \\",13,10
         db "      /  /      \\  \\",13,10
         db "     |  | BIZAA |  |",13,10
         db "     |  |  ARE  |  |",13,10
         db "     |  | $$$$$ |  |",13,10
         db "     |  | ERROR |  |",13,10
         db "     |  |  432  |  |",13,10
         db "      \\  \\______/  /",13,10
         db "       \\          /",13,10
         db "        '--------'",13,10,13,10,0

unknown db "ERROR: unknown command. type HELP.",13,10,0
input_buffer times 64 db 0

times (52*512)-($-$$) db 0

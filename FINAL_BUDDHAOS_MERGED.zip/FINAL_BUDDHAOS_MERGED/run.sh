#!/usr/bin/env bash
set -euo pipefail

nasm -f bin boot.asm -o boot.bin
nasm -f bin kernel.asm -o kernel.bin
cat boot.bin kernel.bin > projectmanhattan_buddhaos.img

qemu-system-i386 -drive format=raw,file=projectmanhattan_buddhaos.img

[org 0x0000]
bits 16

; ============================================================
; Optimized PROJECTMANHATTAN BuddhaOS kernel
; Features preserved. Command dispatch de-duplicated.
; ============================================================

start:
    mov ax, cs
    mov ds, ax
    mov es, ax
    call clear_screen
    call set_green
    mov si, banner
    call puts

main_loop:
    call set_green
    mov si, prompt
    call puts
    mov di, input_buffer
    call read_line

    cmp byte [input_buffer], 0
    je main_loop

    call dispatch_command
    jmp main_loop

; ----------------------------
; Command dispatch table
; ----------------------------

dispatch_command:
    mov bx, command_table
.next:
    mov di, [bx]
    cmp di, 0
    je .unknown

    mov si, input_buffer
    push bx
    call strcmp
    pop bx
    cmp ax, 0
    je .found

    add bx, 4
    jmp .next

.found:
    call word [bx+2]
    ret

.unknown:
    call set_red
    mov si, unknown
    call puts
    ret

command_table:
    dw cmd_help,    do_help
    dw cmd_site,    do_site
    dw cmd_nav,     do_nav
    dw cmd_worlds,  do_worlds
    dw cmd_music,   do_music
    dw cmd_market,  do_market
    dw cmd_fashion, do_fashion
    dw cmd_buddha,  do_buddha
    dw cmd_archive, do_archive
    dw cmd_shop,    do_shop
    dw cmd_arcade,  do_arcade
    dw cmd_lore,    do_lore
    dw cmd_gate,    do_gate
    dw cmd_social,  do_social
    dw cmd_matrix,  do_matrix
    dw cmd_readout, do_readout
    dw cmd_freq,    do_freq
    dw cmd_beer,    do_beer
    dw cmd_money,   do_money
    dw cmd_mantra,  do_mantra
    dw cmd_cls,     do_cls
    dw cmd_reboot,  do_reboot
    dw 0, 0

; ----------------------------
; Command handlers
; ----------------------------

do_help:
    call set_white
    mov si, help_text
    call puts
    ret

do_site:
    call set_green
    mov si, site_text
    call puts
    ret

do_nav:
    call set_white
    mov si, nav_text
    call puts
    ret

do_worlds:
    call set_gold
    mov si, worlds_text
    call puts
    ret

do_music:
    call set_green
    mov si, music_text
    call puts
    ret

do_market:
    call set_green
    mov si, market_text
    call puts
    ret

do_fashion:
    call set_gold
    mov si, fashion_text
    call puts
    ret

do_buddha:
    call set_white
    mov si, buddha_art
    call puts
    ret

do_archive:
    call set_green
    mov si, archive_text
    call puts
    ret

do_shop:
    call set_gold
    mov si, shop_text
    call puts
    ret

do_arcade:
    call set_red
    mov si, arcade_text
    call puts
    ret

do_lore:
    call set_white
    mov si, lore_text
    call puts
    ret

do_gate:
    call set_red
    mov si, gate_text
    call puts
    ret

do_social:
    call set_green
    mov si, social_text
    call puts
    ret

do_matrix:
    call set_green
    mov si, matrix_start
    call puts
    mov cx, MATRIX_ROWS
    mov si, matrix_line
    call repeat_line
    mov si, matrix_end
    call puts
    ret

do_readout:
    call set_green
    mov si, readout_text
    call puts
    mov cx, MATRIX_ROWS
    mov si, matrix_line
    call repeat_line
    ret

do_freq:
    call set_gold
    mov si, freq_text
    call puts
    ret

do_beer:
    call set_white
    mov si, beer_can
    call puts
    ret

do_money:
    call set_green
    mov cx, MONEY_ROWS
    mov si, money_line
    call repeat_line
    ret

do_mantra:
    call set_green
    mov si, mantra
    call puts
    ret

do_cls:
    call clear_screen
    ret

do_reboot:
    int 0x19
    ret

; ----------------------------
; Low-level services
; ----------------------------

clear_screen:
    mov ax, 0x0003
    int 0x10
    ret

set_green:
    mov byte [text_attr], 0x0A
    ret

set_white:
    mov byte [text_attr], 0x0F
    ret

set_gold:
    mov byte [text_attr], 0x0E
    ret

set_red:
    mov byte [text_attr], 0x0C
    ret

putc:
    mov ah, 0x0E
    mov bh, 0
    mov bl, [text_attr]
    int 0x10
    ret

puts:
.next:
    lodsb
    test al, al
    jz .done
    call putc
    jmp .next
.done:
    ret

repeat_line:
    ; SI = line pointer, CX = repeats.
    mov [repeat_ptr], si
.next:
    push cx
    mov si, [repeat_ptr]
    call puts
    pop cx
    loop .next
    ret

read_line:
    xor cx, cx
.read:
    mov ah, 0
    int 0x16

    cmp al, 13
    je .enter
    cmp al, 8
    je .backspace

    ; Drop control chars except Enter/Backspace.
    cmp al, 32
    jb .read

    cmp cx, INPUT_MAX
    jae .read

    ; Normalize lowercase ASCII to uppercase.
    cmp al, 'a'
    jb .store
    cmp al, 'z'
    ja .store
    sub al, 32

.store:
    stosb
    inc cx
    call putc
    jmp .read

.backspace:
    cmp cx, 0
    je .read
    dec di
    dec cx
    mov al, 8
    call putc
    mov al, ' '
    call putc
    mov al, 8
    call putc
    jmp .read

.enter:
    xor al, al
    stosb
    mov al, 13
    call putc
    mov al, 10
    call putc
    ret

strcmp:
    ; SI = typed input, DI = command string.
.loop:
    mov al, [si]
    mov dl, [di]
    cmp al, dl
    jne .no
    test al, al
    jz .yes
    inc si
    inc di
    jmp .loop
.yes:
    xor ax, ax
    ret
.no:
    mov ax, 1
    ret

; ----------------------------
; Constants / Data
; ----------------------------

INPUT_MAX   equ 63
MATRIX_ROWS equ 12
MONEY_ROWS  equ 10

text_attr  db 0x0A
repeat_ptr dw 0

banner db 13,10
       db "========================================================",13,10
       db " A BIT BIZAARE // PROJECTMANHATTAN BuddhaOS",13,10
       db " optimized shell build",13,10
       db " where design becomes identity",13,10
       db "========================================================",13,10
       db "7 worlds | 432 hz | infinity archive | type HELP",13,10,13,10,0

prompt db "bizaare> ",0

cmd_help    db "HELP",0
cmd_site    db "SITE",0
cmd_nav     db "NAV",0
cmd_worlds  db "WORLDS",0
cmd_music   db "MUSIC",0
cmd_market  db "MARKET",0
cmd_fashion db "FASHION",0
cmd_buddha  db "BUDDHA",0
cmd_archive db "ARCHIVE",0
cmd_shop    db "SHOP",0
cmd_arcade  db "ARCADE",0
cmd_lore    db "LORE",0
cmd_gate    db "GATE",0
cmd_social  db "SOCIAL",0
cmd_matrix  db "MATRIX",0
cmd_readout db "READOUT",0
cmd_freq    db "FREQ",0
cmd_beer    db "BEER",0
cmd_money   db "MONEY",0
cmd_mantra  db "MANTRA",0
cmd_cls     db "CLS",0
cmd_reboot  db "REBOOT",0

help_text db "commands:",13,10
          db "  SITE     - website identity",13,10
          db "  NAV      - web nav translated to shell",13,10
          db "  WORLDS   - seven doors, one archive",13,10
          db "  MUSIC    - fenix_the_producer",13,10
          db "  MARKET   - q@w@rd marketplace",13,10
          db "  FASHION  - q@w@rd x zengriffeyjr",13,10
          db "  BUDDHA   - meditating ASCII stage",13,10
          db "  ARCHIVE  - garment/lookbook archive",13,10
          db "  SHOP     - nick knacks",13,10
          db "  ARCADE   - matrix games",13,10
          db "  LORE     - sound/system/ritual",13,10
          db "  GATE     - oppenheimer failsafe",13,10
          db "  SOCIAL   - footer links as shell objects",13,10
          db "  MATRIX   - canvas rain translated to text",13,10
          db "  READOUT  - field readout burst",13,10
          db "  FREQ     - frequency/loop/archive stats",13,10
          db "  BEER     - ASCII can artifact",13,10
          db "  MONEY    - money/error field",13,10
          db "  MANTRA   - suchness",13,10
          db "  CLS      - clear screen",13,10
          db "  REBOOT   - reboot BIOS",13,10,0

site_text db "SITE: A BIT BIZAARE",13,10
          db "fenix_the_producer x Q@W@RD x ZenGriffeyJR",13,10
          db "music, identity marketplace, fashion engine,",13,10
          db "archive, shop, arcade, all in one.",13,10,0

nav_text db "NAV:",13,10
         db "music/ marketplace/ fashion/ buddha/ archive/ shop/ arcade/",13,10
         db "In BuddhaOS these become shell modules.",13,10,0

worlds_text db "SEVEN DOORS, ONE ARCHIVE:",13,10
           db "1 MUSIC    2 MARKETPLACE 3 FASHION",13,10
           db "4 BUDDHA   5 ARCHIVE     6 SHOP",13,10
           db "7 ARCADE",13,10,0

music_text db "MUSIC: fenix_the_producer",13,10
          db "tracks, bio, playable archive, campus-scale soundtracks.",13,10,0

market_text db "MARKETPLACE: Q@W@RD",13,10
           db "Depop x SoundCloud identity market.",13,10
           db "Garments, tracks, fragments, frequency engine.",13,10,0

fashion_text db "FASHION:",13,10
            db "Q@W@RD x ZenGriffeyJR whale-AI fashion engine.",13,10
            db "silhouette, texture, rarity, fit building, drop calendar.",13,10,0

archive_text db "ARCHIVE:",13,10
             db "Samue jacket, streetwear, Dodgers fits,",13,10
             db "first garments in the Q@W@RD archive.",13,10,0

shop_text db "SHOP: Nick Knacks",13,10
         db "Flower Power, Become a Tree, Life is the Revolution.",13,10,0

arcade_text db "ARCADE:",13,10
           db "Code Storm and Matrix Sudoku Gate.",13,10
           db "Do not forget the magic word.",13,10,0

lore_text db "LORE:",13,10
          db "sound: campus-scale soundtrack",13,10
          db "system: Q@W@RD identity marketplace",13,10
          db "ritual: passcode, loop, whale, suchness",13,10,0

gate_text db "OPPENHEIMER FAILSAFE:",13,10
          db "who is the teacher without the hat?",13,10
          db "accepted codes: suchness, 42, teacher without hat.",13,10
          db "BIOS mode: consciousness remains safely reversible.",13,10,0

social_text db "SOCIAL:",13,10
           db "SoundCloud | BandLab | YouTube | TikTok | Instagram | GitHub",13,10,0

freq_text db "STATS:",13,10
          db "worlds = 7",13,10
          db "hz = 432",13,10
          db "loops = counting",13,10
          db "archive = infinity",13,10,0

readout_text db "FIELD READOUT:",13,10
             db "identity frequency closet sound design qaward resonance buddha whale",13,10,0

matrix_start db "MATRIX: translating canvas rain to BIOS text...",13,10,0
matrix_end db "MATRIX: signal stable.",13,10,0
matrix_line db "$$$ A BIT BIZAARE % Q@W@RD # WHALE @ ARCHIVE 0101 $$$",13,10,0
money_line db "$$$$$ ERROR $$$ A BIT BIZAARE $$$ ERROR $$$ Q@W@RD $$$$",13,10,0
mantra db "suchness...",13,10,0

buddha_art db 13,10
           db "           _ooooo_",13,10
           db "        .o888888888o.",13,10
           db "       8888  *  * 8888",13,10
           db "      88       _       88",13,10
           db "      88     \\___/     88",13,10
           db "       88.           .88",13,10
           db "        '88oo_____oo88'",13,10
           db "            /|   |\\",13,10
           db "           / |   | \\",13,10
           db "        __/  |___|  \\__",13,10
           db "      .'   _/     \\_   '.",13,10
           db "     /   .'  .---.  '.   \\",13,10
           db "    /___/   (     )   \\___\\",13,10
           db "       /__   \\___/   __\\",13,10
           db "      (___)   ___   (___)",13,10
           db "        \\____/   \\____/",13,10,13,10,0

beer_can db 13,10
         db "        .--------.",13,10
         db "       /  ______  \\",13,10
         db "      /  /      \\  \\",13,10
         db "     |  | BIZAA |  |",13,10
         db "     |  |  ARE  |  |",13,10
         db "     |  | $$$$$ |  |",13,10
         db "     |  | ERROR |  |",13,10
         db "     |  |  432  |  |",13,10
         db "      \\  \\______/  /",13,10
         db "       \\          /",13,10
         db "        '--------'",13,10,13,10,0

unknown db "ERROR: unknown command. type HELP.",13,10,0
input_buffer times 64 db 0

times (52*512)-($-$$) db 0

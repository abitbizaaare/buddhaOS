@echo off
setlocal

nasm -f bin boot.asm -o boot.bin
if errorlevel 1 exit /b 1

nasm -f bin kernel.asm -o kernel.bin
if errorlevel 1 exit /b 1

copy /b boot.bin+kernel.bin projectmanhattan_buddhaos.img
if errorlevel 1 exit /b 1

echo Built projectmanhattan_buddhaos.img
echo Run with:
echo qemu-system-i386 -drive format=raw,file=projectmanhattan_buddhaos.img

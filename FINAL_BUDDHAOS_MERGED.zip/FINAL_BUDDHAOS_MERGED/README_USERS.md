# FINAL BUDDHAOS MERGED

## A BIT BIZAARE // PROJECTMANHATTAN // Q@W@RD // BuddhaOS

This is the merged one-file package for all BuddhaOS variants created so far.

It combines:

- original `.buddha` boot-sector concept
- BuddhaOS starter shell
- Q@W@RD BuddhaOS patch
- PROJECTMANHATTAN BuddhaOS final shell
- optimized PROJECTMANHATTAN BuddhaOS
- uploaded website companion source
- QEMU/NASM build instructions
- run scripts for Linux/macOS and Windows

---

## What this is

This is a bootable, real-mode, BIOS-era toy operating system shell.

It is not a modern protected-mode OS yet.

It boots into:

```txt
A BIT BIZAARE // PROJECTMANHATTAN BuddhaOS
7 worlds | 432 hz | infinity archive
bizaare>
```

---

## Main files

```txt
boot.asm                 BIOS boot sector
kernel.asm               main BuddhaOS shell
Makefile                 build/run commands
run.sh                   Linux/macOS build + run script
run-debug.sh             debug QEMU launch
build.bat                Windows build script
web/index.html           website companion source
OPTIMIZATION_REPORT.md   optimization/debugging report
legacy/                  older source variants
```

---

## Install requirements

### Ubuntu / Debian

```bash
sudo apt update
sudo apt install nasm qemu-system-x86
```

### Arch

```bash
sudo pacman -S nasm qemu-full
```

### macOS

```bash
brew install nasm qemu
```

### Windows

Use Chocolatey:

```powershell
choco install nasm
choco install qemu
```

Or install NASM and QEMU manually and make sure both are in PATH.

---

## Build and run

### Linux/macOS

```bash
chmod +x run.sh
./run.sh
```

Or:

```bash
make run
```

### Windows

```bat
build.bat
qemu-system-i386 -drive format=raw,file=projectmanhattan_buddhaos.img
```

### Manual build

```bash
nasm -f bin boot.asm -o boot.bin
nasm -f bin kernel.asm -o kernel.bin
cat boot.bin kernel.bin > projectmanhattan_buddhaos.img
qemu-system-i386 -drive format=raw,file=projectmanhattan_buddhaos.img
```

### Debug mode

```bash
./run-debug.sh
```

or:

```bash
qemu-system-i386 \
  -drive format=raw,file=projectmanhattan_buddhaos.img \
  -monitor stdio \
  -d int
```

---

## Commands inside BuddhaOS

At the prompt:

```txt
bizaare>
```

type:

```txt
HELP
```

Available commands:

```txt
SITE
NAV
WORLDS
MUSIC
MARKET
FASHION
BUDDHA
ARCHIVE
SHOP
ARCADE
LORE
GATE
SOCIAL
MATRIX
READOUT
FREQ
BEER
MONEY
MANTRA
CLS
REBOOT
```

---

## Safe commands

If the screen gets noisy:

```txt
CLS
```

If you are lost:

```txt
HELP
```

If you want to restart:

```txt
REBOOT
```

---

## Building QEMU from source

You usually do **not** need this, but if you want to build QEMU manually:

```bash
wget https://download.qemu.org/qemu-11.0.1.tar.xz
tar xvJf qemu-11.0.1.tar.xz
cd qemu-11.0.1
./configure
make -j$(nproc)
sudo make install
```

Build from git:

```bash
git clone https://gitlab.com/qemu-project/qemu.git
cd qemu
./configure
make -j$(nproc)
sudo make install
```

---

## Project philosophy

```txt
KEEP THE SIGNAL
REMOVE THE NOISE
DOCUMENT EVERYTHING
```

This operating system began as:

```asm
mantra db "suchness...",0
```

The rest is archive drift.

---

## Next real OS steps

To become more than a BIOS shell:

```txt
1. Protected mode
2. GDT/IDT
3. Memory manager
4. Disk filesystem
5. Keyboard driver
6. VGA graphics layer
7. Q@W@RD desktop
8. Archive database
```

END README
